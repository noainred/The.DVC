# Handoff: 인프라 / 서비스 성능점검 화면 (The Davinci Virtual Platform)

## Overview
기존 모니터링 포털(The Davinci Virtual Platform)의 상단 메뉴에 **인프라**와 **서비스** 두 개의 점검 탭을 추가하는 화면이다.
레거시 모니터링 도구(트리 + 테스트 목록: Test name / Status / Recurrences / Reply / Test method)의 기능을 포털의 다크 테마 UI로 재구성했다.

- **인프라 탭**: 물리/가상 호스트 기준 점검 (SNMP, Ping, CPU, NTP, Traffic, Disk, Mount, Network Check 등)
- **서비스 탭**: 서비스 기준 점검 (가용성, 로그인 E2E, SSL 만료, API p95/p99, DB 세션·복제 지연, 배치 SLA, 큐 랙, 30일 가용성 등)

## About the Design Files
이 번들의 HTML 파일은 **HTML로 만든 디자인 레퍼런스(프로토타입)** 이다. 의도한 외형과 동작을 보여주는 목적이며, 그대로 제품 코드로 복사해 쓰는 코드가 아니다.
목표는 이 HTML 디자인을 **대상 코드베이스의 기존 환경(React / Vue / 기타)과 기존 컴포넌트·패턴·상태관리 방식으로 재구현**하는 것이다. 아직 환경이 없다면 프로젝트에 가장 적합한 프레임워크를 선택해 구현한다.
데이터는 전부 클라이언트에서 생성한 더미값이다. 실제 구현에서는 모니터링 백엔드 API로 대체해야 한다.

## Fidelity
**High-fidelity (hifi).** 색상, 타이포그래피, 간격, 인터랙션이 확정된 목업이다. 기존 코드베이스의 라이브러리를 쓰되 시각적으로는 픽셀 단위로 동일하게 재현한다.

## Screens / Views

### 1. Header (전역 상단 바)
- **Purpose**: 제품 아이덴티티 + 전역 내비게이션 + 계정/상태 표시
- **Layout**: `display:flex; align-items:center; gap:22px; padding:12px 20px;` 배경 `#0d1626`, 하단 `1px solid #1c2c42`
- **Components**
  - 로고 타일: 38×38, `border-radius:9px`, `linear-gradient(160deg,#2b8cf0,#1d5fb0)`, 글자 "V" 19px/700 흰색
  - 제품명 "The Davinci / Virtual Platform" 14px/700, `#e8f1fb`, `line-height:1.25`
  - 배지: `v2.232.0` (bg `#152539`, fg `#7fa8d4`), `LIVE` (bg `#123024`, fg `#3ddc84`) — 10px mono, `padding:2px 6px`, `radius:4px`
  - 내비 항목: `padding:7px 13px; border-radius:16px;` 기본 fg `#9fb4cc`, hover `background:#152539; color:#e8f1fb`
    순서: Overview · Summary · Platform · **인프라** · **서비스** · 탐색·랭킹 · 호스트 · 가상머신 · 스토리지 · 네트워크 · NSX · 알람 · 특수 기능 · 인사이트 · 설정
  - 활성 탭(인프라 또는 서비스): `background:#1668d8; color:#fff; font-weight:700; box-shadow:0 0 0 1px #4b9bff inset;` 앞에 6px 원형 점 `#7ff0b0` + `pulse 2s ease-in-out infinite` (opacity 1 → .35 → 1)
  - 우측: vCenter 상태 박스 (`padding:8px 14px; border:1px solid #1e3350; radius:18px`, 11px mono, "28/28 vCenter **OK**" — OK는 `#3ddc84`), 아바타 32px 원형 `#1668d8` + 이름/역할

### 2. 섹션 타이틀 바
- `padding:16px 20px 8px`, mono 12px `letter-spacing:.18em` `#5f7fa3`
- 좌: 모드 타이틀 — 인프라 `INFRASTRUCTURE PERFORMANCE TESTS`, 서비스 `SERVICE HEALTH & SLA TESTS`
- 중앙: 1px 그라디언트 라인 `linear-gradient(90deg,#1e3350,transparent)`
- 우: 선택 경로 + 대상 수 (예: `Root\B.Service\A.Data_Landing(SBP)\01.HQ\SBP\Admin · 2 host(s)`)

### 3. 요약 카드 5개
- `display:grid; grid-template-columns:repeat(5,1fr); gap:12px; padding:4px 20px 14px;`
- 카드: `background:#0f1a2b; border:1px solid #1c2c42; border-radius:8px; padding:12px 14px;` + 상단 강조선 `border-top:2px solid <accent>`
- 라벨 11px mono `letter-spacing:.1em` `#7b93ae` / 수치 26px mono 700 / 보조설명 11px `#5f7fa3`
- 카드 정의: TOTAL TESTS `#4b9bff`(수치 `#e8f1fb`) · 정상 `#3ddc84` · 경고 `#f0a92e` · 실패 `#ff5c5c` · 중지 `#6b7f99`(수치 `#8ea4bd`)
- 보조설명: "N개 대상 그룹" / "Ok · Host is alive" / "임계치 근접" / "No answer · Error" / "Disabled"

### 4. 본문 2분할 (좌: 트리, 스플리터, 우: 테스트 목록)
- `display:grid; grid-template-columns:<leftW>px 8px 1fr; gap:6px; padding:0 20px 24px; align-items:start;`
- **스플리터**: 폭 8px, 높이 640px, `cursor:col-resize`, 배경 기본 `#16253a` / hover `#25405f` / 드래그 중 `#2f6fbf`, 가운데 2×34px 바(`#35506f`, 드래그 중 `#9fcaff`)
  - 마우스 드래그로 좌측 폭 조절, **더블클릭 시 340px로 초기화**, 값은 `localStorage['perfcheck.leftW']`에 저장
  - 폭 제한: `min 220px`, `max = max(320, window.innerWidth - 480)`

#### 4-1. 좌측 트리 패널
- 패널: `background:#0f1a2b; border:1px solid #1c2c42; radius:8px; overflow:hidden`
- 헤더: 11px mono `letter-spacing:.12em` `#7b93ae` — 인프라 `TEST TREE` / 서비스 `SERVICE TREE`, 우측에 `N hosts` / `N services`
- 검색 입력: `background:#0a141f; border:1px solid #1e3350; radius:6px; padding:7px 10px;` focus 시 `border-color:#4b9bff`, placeholder "대상 검색"
- 트리 행: `padding:4px 12px 4px (8 + depth*16)px`, hover `#16253a`, 선택 행 `background:#14497f; border-left:2px solid #4b9bff; color:#fff`
  - 확장 토글: 13×13 박스 `border:1px solid #35506f; radius:3px; background:#0d1a29`, 기호 `−`(열림) / `+`(닫힘) / `·`(리프). 클릭 시 `stopPropagation`
  - 라벨 색: 선택 `#fff`, 알람 보유 `#ff8b8b`, 그룹 `#cfe0f2`, 리프 `#9fb4cc` (12.5px, ellipsis)
  - 알람 배지: 우측, 10px mono, `background:#2b1420; color:#ff7b7b; radius:8px; padding:1px 5px`
  - 검색어 입력 시 전체 노드 강제 확장 + 이름 매칭(자식 매칭 포함) 필터

#### 4-2. 우측 테스트 목록 패널
- 툴바: `padding:9px 12px; background:#111e30; border-bottom:1px solid #1c2c42;`
  - 버튼: `padding:6px 12px; border:1px solid #1e3350; radius:6px; background:#152539; color:#cfe0f2;` hover `border-color:#4b9bff`
    `＋ Add` · `✎ Edit` · `✕ Remove` · `⟳ Refresh`(강조: `border:#2b6fc0; background:#153357; color:#9fcaff`, hover `#1a4272`) · `⟲ Reset`
  - 구분선 1×22 `#1e3350`
  - 상태 필터 칩(ALL / OK / WARN / FAIL / DISABLED): `padding:5px 11px; radius:14px;` 비활성 `border #1e3350 / bg #111e30 / fg #8ea4bd`, 활성 `border #4b9bff / bg #153357 / fg #9fcaff`
  - 우측 검색 입력 210px, placeholder "Test name 검색"
- **테이블**: 헤더와 데이터 행을 하나의 `overflow:auto; max-height:660px` 컨테이너 안에 두고 내부 `min-width:920px` 유지. 헤더는 `position:sticky; top:0; z-index:2`
  - 컬럼: `26px minmax(280px,1fr) 118px 96px 190px 210px`
  - 헤더: `background:#132132`, 11px mono `letter-spacing:.06em` `#8ea4bd` — (상태점) · TEST NAME · STATUS · RECURREN… (우측정렬) · REPLY (우측정렬) · TEST METHOD
    - TEST NAME / STATUS 클릭 시 정렬 토글, 활성 시 `▲` 표시
  - 그룹 헤더 행: `padding:7px 12px; background:#14497f; color:#dceaff;` 11.5px mono, `🗀` + 전체 경로(예: `Root\B.Service\…\SBP_Admin01\192.168.10.55`), 우측에 `27 tests · 1 alarm` (`#9fcaff`)
  - 데이터 행: `padding:7px 12px`(dense=true면 4px), `border-bottom:1px solid #131f30`, hover `#16253a`, 선택 행 `#1a3a5f`
    - 상태 점: 9px 원형, `box-shadow:0 0 6px <색>`
    - Test name `#dbe7f5` 13px ellipsis / Status 12px mono(상태색) / Recurrences 12px mono `#8ea4bd` 우측정렬(천단위 콤마) / Reply 12px mono `#cfe0f2` 우측정렬 / Test method 11.5px mono `#7b93ae` ellipsis
  - 빈 상태: `padding:40px; text-align:center; color:#5f7fa3;` "조건에 맞는 점검 항목이 없습니다."
- 푸터: `padding:9px 12px; background:#111e30; border-top:1px solid #1c2c42;` 11px mono `#7b93ae`
  `SHOWN n / total` · `AVG REPLY x ms` · `LAST REFRESH hh:mm:ss` · 우측 `● LIVE POLLING`(`#3ddc84`)

### 5. 상세 모달 (행 클릭 시)
- 오버레이: `position:fixed; inset:0; background:rgba(5,10,18,.65);` 중앙 정렬, `padding:40px`. 오버레이/✕ 클릭 시 닫힘
- 카드: 560px, `background:#0f1a2b; border:1px solid #24405f; radius:10px; box-shadow:0 24px 60px rgba(0,0,0,.55)`
- 헤더: 상태 점 + 테스트명 700 `#e8f1fb` + 우측 `✕` (`#7b93ae`, 16px)
- 본문: `grid-template-columns:120px 1fr; row-gap:10px; column-gap:12px;` 12.5px — Status / Reply / Recurrences / Test method / Path (Path는 11.5px mono `#9fb4cc`, `word-break:break-all`)
- 24H TREND: 24개 막대, 높이 12–100%, `background:#0a141f; border:1px solid #1e3350; radius:6px; padding:8px; height:70px; gap:3px`
  - 막대 색: 값 >88 `#ff5c5c`, >74 `#f0a92e`, 그 외 `#2f80c8`

## Interactions & Behavior
1. **탭 전환** (인프라 ↔ 서비스): 트리 데이터셋과 테스트 항목 생성 로직이 함께 교체된다. 전환 시 선택 노드 초기화(인프라: `Admin`, 서비스: `B.API / Gateway`), 필터/검색/상세 초기화.
2. **트리 노드 선택**: 선택 노드 하위의 대상(호스트 또는 서비스, **최대 8개**)을 수집해 대상별 그룹 헤더 + 테스트 행으로 표시.
3. **트리 확장/축소**: 토글 아이콘 클릭. 검색어가 있으면 강제 확장.
4. **좌우 분할 조절**: 스플리터 mousedown → window mousemove로 폭 갱신 → mouseup에서 localStorage 저장. 드래그 중 `document.body.style.userSelect='none'`.
5. **상태 필터 / 이름 검색 / 정렬**: 클라이언트 필터. 필터 결과가 0인 대상은 그룹 헤더도 표시하지 않음.
6. **Refresh**: 데이터 tick 증가 + `LAST REFRESH`를 현재 시각(ko-KR, 24h)으로 갱신. **Reset**: 필터/검색/정렬 초기화.
7. **자동 폴링**: 4초 간격 tick (실제 구현에서는 API 재조회 주기로 대체).
8. **Add / Edit / Remove**: 현재 목업에서는 비동작. 실제 구현 시 점검 항목 CRUD 모달이 필요하다.

## State Management
| 상태 | 초기값 | 설명 |
|---|---|---|
| `mode` | `'infra'` | `'infra'` \| `'service'` — 상단 탭 |
| `sel` | `'admin'` | 선택된 트리 노드 id |
| `expanded` | 주요 노드 true | `{ [nodeId]: boolean }` (미지정은 열림으로 간주) |
| `leftW` | `340` | 좌측 패널 폭(px), localStorage 유지 |
| `dragging` | `false` | 스플리터 드래그 중 |
| `treeQuery` / `testQuery` | `''` | 트리 / 테스트명 검색어 |
| `filter` | `'ALL'` | `ALL` \| `OK` \| `WARN` \| `BAD` \| `OFF` |
| `sort` | `'none'` | `none` \| `name` \| `status` |
| `detail` | `null` | 상세 모달 대상 행 |
| `tick` | `0` | 폴링 카운터 |
| `lastRefresh` | `'08:10:24'` | 마지막 갱신 시각 |

상태 매핑(색상 결정): `Ok`/`Host is alive` → OK `#3ddc84`, `Warning` → WARN `#f0a92e`, `Disabled` → OFF `#7b8fa8`, 그 외(`No answer`, `Error`) → BAD `#ff5c5c`.

**데이터 요구사항** — 실제 API는 다음을 제공해야 한다: 점검 대상 트리(노드 id/이름/부모/호스트 또는 서비스 엔드포인트/알람 수), 대상별 점검 항목 목록(name, status, recurrences, reply, test method), 항목별 24시간 추이 시계열, 갱신 시각.

## Design Tokens
**Colors**
| 용도 | 값 |
|---|---|
| 페이지 배경 | `#0a111c` |
| 헤더/툴바/푸터 배경 | `#0d1626`, `#111e30` |
| 패널 배경 | `#0f1a2b` |
| 테이블 헤더 배경 | `#132132` |
| 입력 배경 | `#0a141f` |
| 보더 | `#1c2c42`, `#1e3350`, `#131f30`, `#24405f` |
| 선택/그룹 헤더 | `#14497f`, 선택 행 `#1a3a5f` |
| 강조(Primary) | `#1668d8`, 라인 `#4b9bff`, 텍스트 `#9fcaff` |
| 본문 텍스트 | `#c8d6e8` / 강조 `#e8f1fb` / 값 `#dbe7f5` |
| 보조 텍스트 | `#9fb4cc`, `#8ea4bd`, `#7b93ae`, `#5f7fa3` |
| 상태 | OK `#3ddc84` · WARN `#f0a92e` · FAIL `#ff5c5c` · OFF `#7b8fa8` |
| 알람 라벨/배지 | `#ff8b8b`, `#ff7b7b` / bg `#2b1420` |
| hover 표면 | `#16253a`, `#152539`, `#25405f` |

**Typography**: 본문 `'Noto Sans KR', system-ui, sans-serif` / 수치·경로·라벨 `'JetBrains Mono', monospace`
스케일: 26px/700(카드 수치) · 19px/700(로고) · 14px/700(제품명) · 13px(기본) · 12.5px(트리·모달 본문) · 12px(값) · 11.5px(경로·method) · 11px(라벨, `letter-spacing:.06–.18em`) · 10px(배지)

**Spacing**: 2 · 4 · 6 · 7 · 8 · 9 · 10 · 12 · 14 · 16 · 18 · 20 · 22px (트리 들여쓰기 16px/depth)
**Radius**: 3 · 4 · 6 · 8 · 9 · 10 · 14 · 16 · 18px · 50%
**Shadows**: `0 24px 60px rgba(0,0,0,.55)`(모달), `0 0 6px <상태색>`(상태 점), `0 0 0 1px <색> inset`(활성 탭)
**Animation**: `@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.35} }` — 2s ease-in-out infinite
**Scrollbar**: 10px, track `#0d1626`, thumb `#22364f` / hover `#2f4a6b`, radius 6px

## Assets
이미지 에셋 없음. 로고는 CSS 그라디언트 + 텍스트, 아이콘은 유니코드 문자(`＋ ✎ ✕ ⟳ ⟲ 🗀 ▲ − +`)로 처리했다.
실제 구현에서는 코드베이스의 아이콘 세트(예: lucide, heroicons)로 대체할 것을 권장한다. 폰트는 Google Fonts의 Noto Sans KR, JetBrains Mono.

## Files
- `design/perf-check.dc.html` — 원본 디자인 소스(마크업 + 로직). 색상·간격·문구의 기준 파일.
- `design/perf-check-standalone.html` — 브라우저에서 바로 열어볼 수 있는 단일 파일 버전(동작 확인용).

## Claude Code에서 시작하는 방법
1. 이 폴더를 대상 저장소 루트에 두고 Claude Code를 실행한다.
2. 다음과 같이 지시한다:
   > `design_handoff_perf_check/README.md`를 읽고, `design/perf-check-standalone.html`을 브라우저로 열어 확인한 뒤, 이 화면을 우리 코드베이스의 기존 컴포넌트와 패턴으로 재구현해줘. 더미 데이터는 `<실제 API>`로 연결하고, 색상·간격·타이포는 README의 토큰을 그대로 따라줘.
3. 먼저 인프라 탭 + 트리/테이블/스플리터를 구현하고, 그다음 서비스 탭과 상세 모달을 붙이는 순서를 권장한다.
